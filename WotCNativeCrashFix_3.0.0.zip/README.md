# WotC Native Crash Fix 3.0.0 — AML-controlled candidate

This package adds **WotC Native Crash Fix** as a selectable local mod in AML.
It controls both the HQ buffer-growth repair and the candidate Avenger-return
`IsPlayerControlled` null guard.

A native bootstrap DLL is also required beside XCom2.exe. Windows loads that
bootstrap on every launch; AML's checkbox controls whether the fixes are active.
This is not a script-only or Workshop-only mod. No replacement launcher,
PowerShell installer, background service, or separate launch command is included.

## Install and enable

1. Close XCOM. Copy the included `XCom2-WarOfTheChosen` folder into your existing
   `.../steamapps/common/XCOM 2/` directory, merging its folders. The resulting
   DLL must be `XCom2-WarOfTheChosen/Binaries/Win64/dinput8.dll`, and the mod
   descriptor must be `XCom2-WarOfTheChosen/XComGame/Mods/WotCNativeCrashFix/`
   `WotCNativeCrashFix.XComMod`.
2. If you installed my earlier 2.0 bootstrap, replace that package's dinput8.dll
   with this one. If an unrelated mod already owns dinput8.dll, this package
   cannot coexist at that filename; chaining has not been implemented. Do not
   overwrite another mod's DLL.
3. In AML, ensure `.../XCom2-WarOfTheChosen/XComGame/Mods` is among the configured
   mod directories. Refresh/restart AML if needed, then check **WotC Native
   Crash Fix** and launch WotC normally through AML.
4. On first enabled use, acknowledge the restart message. XCOM closes. Launch
   it again through AML with the mod still checked. No installer script needs
   to be run.

## Launch behavior

On a completely fresh install, the first launch resolves your actual Windows
Documents folder (including OneDrive/redirected folders), saves its path, and
requests restart. It does **not** patch late into a running game. On the next
launch, the bootstrap reads AML's current active-mod list and installs both
fixes in memory **before the game's entry point**. The setup marker suppresses
further restart requests, but never skips patch initialization or verification.

If the configuration path was already initialized while the mod was disabled,
the first enabled launch applies both fixes before game startup and then asks
for the one-time restart.

The repairs stay in executable memory for the entire process. Returning to the
Avenger, loading another save, or starting another mission does not unload them.
The Avenger repair targets the null dereference identified in your supplied
crash; it has not been confirmed against an actual in-game Avenger return.

Uncheck the mod and **start a new game process through AML** to disable it.
Toggling AML while XCOM is already running cannot change that process. On the
supported original build, no fix is installed while unchecked. For the exact
known R1/combined 1.1 disk-patched builds, the bootstrap restores the original
instructions **in memory only** while unchecked, so the old patch does not
silently bypass the checkbox. Game executable files are never rewritten.
Unknown builds are left unchanged while disabled and rejected while enabled.

## Status and removal

The most recent startup log is under `%LOCALAPPDATA%/XCOM2NativeCrashFix/`, named
with a game-path hash followed by `-startup.log`. It reports enabled, disabled,
setup-restart, or failure. Successful enabled startup verifies both patch sites.
A failure on an enabled launch closes the game before forwarding DirectInput.

To remove this package, close XCOM, remove its `WotCNativeCrashFix` mod folder,
and remove **this package's** `Binaries/Win64/dinput8.dll`. No save is modified.
If an earlier fix permanently patched your executable, removing the bootstrap
exposes that disk patch again; use your original executable backup to remove
that older patch too. Unchecking this mod while leaving its bootstrap installed
neutralizes the recognized older patches for that process.

## What was tested

Compiled native code was exercised under emulation with mocked Windows APIs.
See `LOADER_VALIDATION.json` for launcher selection, restart, re-enable, disabled
legacy-patch handling, redirected Documents paths, and binary validation cases.
`PATCH_VALIDATION.json` records the earlier machine-code tests of the same two
repair routines. **No actual Windows launch, AML discovery, save load, or Avenger
return was tested here. This is a candidate build, not a verified in-game fix.**

The supported original executable is the supplied AMD64 WotC build with PE
timestamp `0x621562fa` and original SHA-256
`d830aad0bdc5aea35e3a62f51cbd7f0c22b4d297ac3c02cdea37a746fde110ae`.
The loader checks the PE build and exact affected bytes; it also recognizes the
specific R1 and combined 1.1 variants produced earlier in this conversation.
