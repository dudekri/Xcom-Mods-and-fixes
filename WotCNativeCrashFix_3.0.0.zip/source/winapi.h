#ifndef WINAPI_MIN_H
#define WINAPI_MIN_H
typedef unsigned char BYTE;
typedef unsigned short WCHAR;
typedef unsigned int DWORD;
typedef int BOOL;
typedef int HRESULT;
typedef unsigned long long SIZE_T;
typedef void *HANDLE;
typedef void *HMODULE;
typedef void *LPVOID;
typedef struct { void *ptr; } INIT_ONCE;
#define W(s) ((const WCHAR*)u##s)
#define API(ret,name,args) extern ret (*__imp_##name) args
#define CALL(name) (*__imp_##name)
API(HMODULE,GetModuleHandleW,(const WCHAR*));
API(BOOL,VirtualProtect,(void*,SIZE_T,DWORD,DWORD*));
API(void*,VirtualAlloc,(void*,SIZE_T,DWORD,DWORD));
API(BOOL,VirtualFree,(void*,SIZE_T,DWORD));
API(BOOL,FlushInstructionCache,(HANDLE,const void*,SIZE_T));
API(BOOL,DisableThreadLibraryCalls,(HMODULE));
API(DWORD,GetSystemDirectoryW,(WCHAR*,DWORD));
API(HMODULE,LoadLibraryExW,(const WCHAR*,HANDLE,DWORD));
API(void*,GetProcAddress,(HMODULE,const char*));
API(BOOL,InitOnceExecuteOnce,(INIT_ONCE*,BOOL(*)(INIT_ONCE*,void*,void**),void*,void**));
API(DWORD,GetEnvironmentVariableW,(const WCHAR*,WCHAR*,DWORD));
API(DWORD,GetModuleFileNameW,(HMODULE,WCHAR*,DWORD));
API(BOOL,CreateDirectoryW,(const WCHAR*,void*));
API(HANDLE,CreateFileW,(const WCHAR*,DWORD,DWORD,void*,DWORD,DWORD,HANDLE));
API(BOOL,WriteFile,(HANDLE,const void*,DWORD,DWORD*,void*));
API(BOOL,ReadFile,(HANDLE,void*,DWORD,DWORD*,void*));
API(BOOL,CloseHandle,(HANDLE));
API(DWORD,GetFileAttributesW,(const WCHAR*));
API(void,ExitProcess,(DWORD));
API(int,MessageBoxW,(HANDLE,const WCHAR*,const WCHAR*,DWORD));
#endif
