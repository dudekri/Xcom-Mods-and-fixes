"""Execute the built Windows DLL in Unicorn with instrumented Win32 API stubs.
This validates native code and lifecycle logic, not the real Windows loader.
"""
import json,struct,sys
from pathlib import Path
import pefile
from unicorn import Uc,UC_ARCH_X86,UC_MODE_64,UC_HOOK_CODE
from unicorn.x86_const import *
ROOT=Path(__file__).resolve().parents[1]
GAME=pefile.PE(sys.argv[1]);R2=pefile.PE(sys.argv[2]);DLL=ROOT/'build/dinput8.dll'
B=0x140000000;STACK=0x70000000;STOP=0x400ff000;APIS=0x40000000;ALLOC=0x30000000
PATH='C:\\Games\\XCOM 2\\XCom2-WarOfTheChosen\\Binaries\\Win64\\XCom2.exe'
DOCS='C:\\Users\\Test\\OneDrive\\Documents'
CONFIG=DOCS+'\\My Games\\XCOM2 War of the Chosen\\XComGame\\Config\\XComModOptions.ini'
MODFILE=PATH.rsplit('\\',3)[0]+'\\XComGame\\Mods\\WotCNativeCrashFix\\WotCNativeCrashFix.XComMod'
ACTIVE=b'[Engine.XComModOptions]\r\nActiveMods=OtherMod\r\nActiveMods=WotCNativeCrashFix\r\n'
PAGES={r:bytes(GAME.get_data(r,4096)) for r in [0,0xbc000,0xccc000]}
R1_GROWTH=bytes(R2.get_data(0xbc182,19));R2_GUARD=bytes(R2.get_data(0xccc660,102));STUB=bytes(R2.get_data(0x20c7000,31))
class Sim:
 def __init__(self,kind='original',base=0x180000000,files=None,answer=6,fail_protect=False,active=True,cached=True,mod=True,config=None,docs=DOCS):
  self.kind=kind;self.base=base;self.files=files if files is not None else {};self.answer=answer;self.fail_protect=fail_protect
  self.docs=docs
  config_path=docs+'\\My Games\\XCOM2 War of the Chosen\\XComGame\\Config\\XComModOptions.ini'
  if mod:self.files[MODFILE]=b'[mod]'
  else:self.files.pop(MODFILE,None)
  self.files[config_path]=config if config is not None else (ACTIVE if active else b'[Engine.XComModOptions]\r\nActiveMods=OtherMod\r\n')
  hash=14695981039346656037
  for c in PATH:hash=((hash^ord(c))*1099511628211)&0xffffffffffffffff
  self.cache='C:\\Users\\Test\\AppData\\Local\\XCOM2NativeCrashFix\\'+format(hash,'016x')+'-v3.config-path'
  if cached and self.cache not in self.files:self.files[self.cache]=(config_path+'\0').encode('utf-16le')
  self.calls=[];self.messages=[];self.exit=None;self.forwarded=[];self.handles={};self.once_ptr=None
  self.u=Uc(UC_ARCH_X86,UC_MODE_64);u=self.u
  p=pefile.PE(str(DLL));p.relocate_image(base);self.p=p
  u.mem_map(base,p.OPTIONAL_HEADER.SizeOfImage);u.mem_write(base,bytes(p.get_memory_mapped_image()))
  for r,data in PAGES.items():u.mem_map(B+r,4096);u.mem_write(B+r,data)
  if kind in ['r1','r2']:
   u.mem_map(B+0x20c7000,4096);u.mem_write(B+0x20c7000,STUB);u.mem_write(B+0xbc182,R1_GROWTH)
   self.w32(B+GAME.DOS_HEADER.e_lfanew+24+56,0x20c8000)
  if kind=='r2':u.mem_write(B+0xccc660,R2_GUARD)
  if kind=='unknown':self.w32(B+GAME.DOS_HEADER.e_lfanew+8,0)
  if kind=='tampered':u.mem_write(B+0xccc660,b'\x90')
  self.before_growth=bytes(u.mem_read(B+0xbc182,19));self.before_guard=bytes(u.mem_read(B+0xccc660,102))
  u.mem_map(STACK,0x20000);u.mem_map(APIS,0x100000);u.mem_map(ALLOC,4096)
  self.api={};self.real={};index=0
  for d in p.DIRECTORY_ENTRY_IMPORT:
   assert d.dll in [b'KERNEL32.dll',b'USER32.dll']
   for imp in d.imports:
    a=APIS+index*16;index+=1;self.api[a]=imp.name.decode();u.mem_write(imp.address,struct.pack('<Q',a))
  for i,n in enumerate(['DirectInput8Create','DllCanUnloadNow','DllGetClassObject','DllRegisterServer','DllUnregisterServer','GetdfDIJoystick']):self.real[n]=APIS+0x10000+i*16
  self.documents_api=APIS+0x18000
  self.after_once=APIS+0x20000
  self.exports={e.name.decode():base+e.address for e in p.DIRECTORY_ENTRY_EXPORT.symbols}
  u.hook_add(UC_HOOK_CODE,self.hook)
 def r(self,r):return self.u.reg_read(r)
 def q(self,a):return struct.unpack('<Q',self.u.mem_read(a,8))[0]
 def w32(self,a,v):self.u.mem_write(a,struct.pack('<I',v))
 def string(self,a,wide=False):
  result=bytearray();step=2 if wide else 1
  while True:
   v=bytes(self.u.mem_read(a,step));a+=step
   if not any(v):break
   result+=v
  return result.decode('utf-16le' if wide else 'ascii')
 def wstr(self,a,s):self.u.mem_write(a,s.encode('utf-16le')+b'\0\0');return len(s)
 def ret(self,v):
  sp=self.r(UC_X86_REG_RSP);self.u.reg_write(UC_X86_REG_RAX,v&0xffffffffffffffff);self.u.reg_write(UC_X86_REG_RIP,self.q(sp));self.u.reg_write(UC_X86_REG_RSP,sp+8)
 def hook(self,u,a,size,user):
  if a==self.after_once:
   u.mem_write(self.once_ptr,struct.pack('<Q',1));self.ret(1);return
  if a==self.documents_api:
   self.wstr(self.q(self.r(UC_X86_REG_RSP)+40),self.docs);self.ret(0);return
  if a in self.real.values():
   args=[self.r(x) for x in [UC_X86_REG_RCX,UC_X86_REG_RDX,UC_X86_REG_R8,UC_X86_REG_R9]]+[self.q(self.r(UC_X86_REG_RSP)+40)]
   self.forwarded.append(args);self.ret(0x12345678);return
  name=self.api.get(a)
  if not name:return
  self.calls.append(name)
  x,y,z,w=[self.r(r) for r in [UC_X86_REG_RCX,UC_X86_REG_RDX,UC_X86_REG_R8,UC_X86_REG_R9]]
  value=1
  if name=='GetModuleHandleW':value=B
  elif name=='VirtualAlloc':value=ALLOC
  elif name=='VirtualProtect':self.w32(w,0x20);value=0 if self.fail_protect else 1
  elif name in ['VirtualFree','FlushInstructionCache','DisableThreadLibraryCalls','CloseHandle','CreateDirectoryW']:pass
  elif name=='GetEnvironmentVariableW':assert self.string(x,True)=='LOCALAPPDATA';value=self.wstr(y,'C:\\Users\\Test\\AppData\\Local')
  elif name=='GetModuleFileNameW':value=self.wstr(y,PATH if not x else PATH.rsplit('\\',1)[0]+'\\dinput8.dll')
  elif name=='GetSystemDirectoryW':value=self.wstr(x,'C:\\Windows\\System32')
  elif name=='LoadLibraryExW':assert self.string(x,True) in ['C:\\Windows\\System32\\dinput8.dll','C:\\Windows\\System32\\shell32.dll'];assert z==0x800;value=0x999000
  elif name=='GetProcAddress':value=self.documents_api if self.string(y)=='SHGetFolderPathW' else self.real[self.string(y)]
  elif name=='GetFileAttributesW':value=0x80 if self.string(x,True) in self.files else 0xffffffff
  elif name=='CreateFileW':
   path=self.string(x,True)
   if y==0x80000000 and path not in self.files:value=0xffffffffffffffff
   else:
    value=len(self.handles)+10;self.handles[value]=path
    if y!=0x80000000:self.files[path]=b''
  elif name=='ReadFile':
   data=self.files[self.handles[x]][:z];u.mem_write(y,data);self.w32(w,len(data))
  elif name=='WriteFile':self.files[self.handles[x]]=bytes(u.mem_read(y,z));self.w32(w,z)
  elif name=='MessageBoxW':self.messages.append((self.string(y,True),self.string(z,True),w));value=self.answer
  elif name=='ExitProcess':self.exit=x;u.emu_stop();return
  elif name=='InitOnceExecuteOnce':
   if self.q(x):self.ret(1);return
   self.once_ptr=x;sp=self.r(UC_X86_REG_RSP)-8;u.mem_write(sp,struct.pack('<Q',self.after_once));u.reg_write(UC_X86_REG_RSP,sp)
   u.reg_write(UC_X86_REG_RCX,x);u.reg_write(UC_X86_REG_RDX,z);u.reg_write(UC_X86_REG_R8,w);u.reg_write(UC_X86_REG_RIP,y);return
  else:raise AssertionError(name)
  self.ret(value)
 def invoke(self,addr,args):
  sp=STACK+0x18000-8;self.u.mem_write(sp,struct.pack('<Q',STOP));self.u.reg_write(UC_X86_REG_RSP,sp)
  for r,v in zip([UC_X86_REG_RCX,UC_X86_REG_RDX,UC_X86_REG_R8,UC_X86_REG_R9],args):self.u.reg_write(r,v)
  for i,v in enumerate(args[4:]):self.u.mem_write(sp+40+8*i,struct.pack('<Q',v))
  self.u.emu_start(addr,STOP,count=500000)
  assert self.exit is not None or self.r(UC_X86_REG_RIP)==STOP,'execution limit'
  return self.r(UC_X86_REG_RAX)
 def boot(self):
  self.invoke(self.base+self.p.OPTIONAL_HEADER.AddressOfEntryPoint,[self.base,1,0])
  assert not any(n in self.calls for n in ['LoadLibraryExW','MessageBoxW','InitOnceExecuteOnce'])
 def input(self):return self.invoke(self.exports['DirectInput8Create'],[0x111,0x800,0x222,0x333,0x444])
 def patched(self):
  assert bytes(self.u.mem_read(B+0xccc660,102))==R2_GUARD
  if self.kind=='original':
   expected=b'\xff\x25\0\0\0\0'+struct.pack('<Q',ALLOC)+b'\x90'*5
   assert bytes(self.u.mem_read(B+0xbc182,19))==expected
   assert bytes(self.u.mem_read(ALLOC,31))==STUB
  else:assert bytes(self.u.mem_read(B+0xbc182,19))==R1_GROWTH

cases=0
for base in [0x180000000,0x7ffa12340000]:
 for kind in ['original','r1','r2']:
  files={};s=Sim(kind,base,files,cached=False);s.boot()
  assert bytes(s.u.mem_read(B+0xbc182,19))==bytes(GAME.get_data(0xbc182,19))
  assert bytes(s.u.mem_read(B+0xccc660,102))==bytes(GAME.get_data(0xccc660,102))
  s.input();assert s.exit==0 and len(s.messages)==1 and not s.forwarded
  assert any(p.endswith('.complete') for p in files);cases+=1
  s=Sim(kind,base,files);s.boot();s.patched();assert s.input()==0x12345678
  assert s.exit is None and not s.messages and s.forwarded==[[0x111,0x800,0x222,0x333,0x444]]
  s.input();assert len(s.forwarded)==2 and not s.messages;cases+=1
  s=Sim(kind,base,files,active=False);s.boot()
  assert bytes(s.u.mem_read(B+0xbc182,19))==bytes(GAME.get_data(0xbc182,19))
  assert bytes(s.u.mem_read(B+0xccc660,102))==bytes(GAME.get_data(0xccc660,102))
  assert s.input()==0x12345678 and not s.messages and s.exit is None;cases+=1
  s=Sim(kind,base,files);s.boot();s.patched();s.input();assert not s.messages and s.exit is None;cases+=1
 # Cached path from an earlier disabled run: first enabled run patches and asks once.
 files={};s=Sim('original',base,files,active=False,cached=False);s.boot();s.input()
 assert s.exit is None and not s.messages;cases+=1
 s=Sim('original',base,files);s.boot();s.patched();s.input();assert s.exit==0 and len(s.messages)==1;cases+=1
 for kind,fail in [('unknown',False),('tampered',False),('original',True)]:
  s=Sim(kind,base,fail_protect=fail);s.boot()
  assert bytes(s.u.mem_read(B+0xbc182,19))==s.before_growth and bytes(s.u.mem_read(B+0xccc660,102))==s.before_guard
  s.input();assert s.exit==1 and s.messages and not s.forwarded and not any(p.endswith('.complete') for p in s.files);cases+=1
 # Disabled unsupported executable must forward without applying or blocking.
 for kind in ['unknown','tampered']:
  s=Sim(kind,base,active=False);s.boot();assert s.input()==0x12345678 and s.exit is None and not s.messages
  assert bytes(s.u.mem_read(B+0xbc182,19))==s.before_growth and bytes(s.u.mem_read(B+0xccc660,102))==s.before_guard;cases+=1
 s=Sim('original',base,mod=False);s.boot();s.input();assert not s.messages and s.exit is None and bytes(s.u.mem_read(B+0xbc182,19))==s.before_growth;cases+=1
 # A redirected Documents folder changing requires restart before gameplay.
 files={};s=Sim('original',base,files);s.boot();s.input()
 s=Sim('original',base,files,docs='D:\\Documents');s.boot();s.input();assert s.exit==0 and len(s.messages)==1;cases+=1
 s=Sim('original',base,files,docs='D:\\Documents');s.boot();s.patched();s.input();assert s.exit is None and not s.messages;cases+=1
 # Exact selection, not substring or a comment; official AML format and UE operators.
 formats=[
  (b'[Engine.XComModOptions]\nActiveMods=WotCNativeCrashFix\n',True),
  (b'\xef\xbb\xbf[engine.xcommodoptions]\n +ActiveMods = "wotcnativecrashfix" \n',True),
  (b'[Other]\nActiveMods=WotCNativeCrashFix\n',False),
  (b'[Engine.XComModOptions]\n;ActiveMods=WotCNativeCrashFix\n',False),
  (b'[Engine.XComModOptions]\nActiveMods=WotCNativeCrashFixExtra\n',False),
  (b'[Engine.XComModOptions]\n+ActiveMods=WotCNativeCrashFix\n-ActiveMods=WotCNativeCrashFix\n',False),
  (b'[Engine.XComModOptions]\nActiveMods=WotCNativeCrashFix\n!ActiveMods=ClearArray\n',False),
  (b'[Engine.XComModOptions]\n!ActiveMods=ClearArray\n.ActiveMods=WotCNativeCrashFix',True),
  (b'',False),
  (b'x'*1048576,False),
 ]
 formats.extend([(b'\xff\xfe'+ACTIVE.decode().encode('utf-16le'),True),(b'\xfe\xff'+ACTIVE.decode().encode('utf-16be'),True)])
 for data,enabled in formats:
  s=Sim('original',base,config=data);s.boot();s.input()
  if enabled:s.patched();assert s.exit==0 and s.messages
  else:assert s.exit is None and not s.messages and bytes(s.u.mem_read(B+0xbc182,19))==s.before_growth
  cases+=1
p=pefile.PE(str(DLL));assert p.OPTIONAL_HEADER.DATA_DIRECTORY[3].Size>0 and p.OPTIONAL_HEADER.DATA_DIRECTORY[5].Size>0
result={'native_loader_scenarios_passed':cases,'DLL_image_bases_tested':2,'tested_inputs':['original','buffer R1','combined 1.1'],'verified':['AML exact mod ID selection in current user config','no late patching: writes happen only before executable entry point','redirected Documents folder resolution outside loader lock','first-use configuration restart','later enabled launches apply both fixes without further prompts','disabled launches restore known legacy patches in memory only','re-enable after disabling','missing mod descriptor deactivates fixes','UTF-8 BOM and UTF-16 LE/BE configuration','configuration comments, sections, removals and exact ID','five-argument DirectInput forwarding','unsupported/tampered enabled build rejection without writes','memory protection failure without writes','PE imports/exports/unwind/ASLR directories'],'real_Windows_game_test':'not performed; candidate build, not game-validated'}
print(json.dumps(result,indent=2))
