"""Build with GNU gcc/objcopy/ld (PE support) on Linux. No Windows SDK needed.
The tiny generated import-provider DLLs exist only to make import libraries;
never install them. Only build/dinput8.dll is the deliverable.
"""
import re, subprocess, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]; SRC=ROOT/'source'; BUILD=ROOT/'build'; BUILD.mkdir(exist_ok=True)
def run(*cmd):subprocess.run(list(map(str,cmd)),check=True,cwd=ROOT)
flags=['-std=c11','-Os','-mabi=ms','-maccumulate-outgoing-args','-mno-red-zone','-mgeneral-regs-only','-fpie','-ffreestanding','-fno-builtin','-fno-stack-protector','-fno-asynchronous-unwind-tables','-fno-unwind-tables','-fno-inline','-fno-optimize-sibling-calls','-fno-shrink-wrap','-fno-shrink-wrap-separate','-fno-reorder-blocks-and-partition','-fno-ipa-cp','-fno-tree-loop-distribute-patterns','-Wall','-Wextra','-Werror']
header=(SRC/'winapi.h').read_text();names=re.findall(r'^API\([^,]+,(\w+),',header,re.M)
for dll,api in [('KERNEL32',[x for x in names if x!='MessageBoxW']),('USER32',['MessageBoxW'])]:
    dummy=BUILD/(dll+'.c');dummy.write_text('\n'.join('void '+n+'(void){}' for n in api)+'\n')
    defs=BUILD/(dll+'.def');defs.write_text('LIBRARY '+dll+'.dll\nEXPORTS\n'+'\n'.join(api)+'\n')
    run('gcc',*flags,'-c',dummy,'-o',BUILD/(dll+'.elf.o'))
    run('objcopy','-O','pe-x86-64','--remove-section=.comment','--remove-section=.note.GNU-stack',BUILD/(dll+'.elf.o'),BUILD/(dll+'.obj'))
    run('ld','-mi386pep','--dll','--entry',api[0],BUILD/(dll+'.obj'),defs,'--out-implib',BUILD/('lib'+dll+'.a'),'-o',BUILD/(dll+'.dll'))
run('gcc',*flags,'-c',SRC/'autoinit.c','-o',BUILD/'autoinit.elf.o')
run(sys.executable,SRC/'elf_to_coff.py',BUILD/'autoinit.elf.o',BUILD/'autoinit.obj')
run('ld','-mi386pep','--dll','--entry','DllMain','--image-base','0x180000000','--dynamicbase','--nxcompat','--no-insert-timestamp','--subsystem','windows',BUILD/'autoinit.obj',SRC/'dinput8.def',BUILD/'libKERNEL32.a',BUILD/'libUSER32.a','-o',BUILD/'dinput8.dll','-Map',BUILD/'dinput8.map')
print(BUILD/'dinput8.dll')
