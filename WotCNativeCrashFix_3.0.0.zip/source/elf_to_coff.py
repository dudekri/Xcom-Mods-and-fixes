"""Narrow ELF64 -> AMD64 COFF converter for this freestanding MS-ABI build.
Preserves PC-relative addends and emits Windows unwind metadata for GCC's
fixed push/sub prologues. Rejects unsupported relocations and stack frames.
Requires capstone for prologue decoding. Not a general object converter.
"""
import math,struct,sys
from pathlib import Path
from capstone import Cs,CS_ARCH_X86,CS_MODE_64

def convert(src,dst):
 b=Path(src).read_bytes();assert b[:5]==b'\x7fELF\x02'
 shoff=struct.unpack_from('<Q',b,40)[0];ents,n,strings=struct.unpack_from('<HHH',b,58)
 sh=[struct.unpack_from('<IIQQQQIIQQ',b,shoff+i*ents) for i in range(n)]
 def raw(i):return b[sh[i][4]:sh[i][4]+sh[i][5]]
 def z(s,o):return s[o:s.index(0,o)].decode()
 names=[z(raw(strings),s[0]) for s in sh]
 sec=[];mapping={}
 for i,s in enumerate(sh):
  if s[2]&2:
   mapping[i]=len(sec)+1
   flags=0x60000020 if s[2]&4 else (0xc0000080 if s[1]==8 else (0xc0000040 if s[2]&1 else 0x40000040))
   flags|=(int(math.log2(max(1,s[8])))+1)<<20
   sec.append({'name':names[i],'data':bytearray() if s[1]==8 else bytearray(raw(i)),'size':s[5],'flags':flags,'relocs':[],'bss':s[1]==8})
 syms=[];elfmap={};functions=[]
 symidx=next(i for i,s in enumerate(sh) if s[1]==2);strdata=raw(sh[symidx][6]);symdata=raw(symidx)
 for i in range(len(symdata)//24):
  name,info,other,index,value,size=struct.unpack_from('<IBBHQQ',symdata,i*24)
  typ=info&15;binding=info>>4
  if i==0 or typ==4:continue
  if index!=0 and index not in mapping:continue
  name=z(strdata,name) if name else names[index]
  elfmap[i]=len(syms)
  syms.append((name,value,mapping.get(index,0),0x20 if typ==2 else 0,2 if binding else 3))
  if typ==2 and size: functions.append((mapping[index],value,size,len(syms)-1))
 for i,s in enumerate(sh):
  if s[1]!=4 or s[7] not in mapping:continue
  target=sec[mapping[s[7]]-1];data=raw(i)
  for off in range(0,len(data),24):
   pos,info,add=struct.unpack_from('<QQq',data,off);sym=info>>32;typ=info&0xffffffff
   if typ in (2,4):ctyp=4;fmt='<i';add+=4
   elif typ==1:ctyp=1;fmt='<Q';add&=(1<<64)-1
   else:raise ValueError(('unsupported relocation',typ))
   struct.pack_into(fmt,target['data'],pos,add)
   target['relocs'].append((pos,elfmap[sym],ctyp))
 # Fixed-prologue Windows unwind information.
 xdata=bytearray();pdata=bytearray();pr=[];cs=Cs(CS_ARCH_X86,CS_MODE_64)
 xsec=len(sec)+1; xsym=len(syms);syms.append(('.xdata',0,xsec,0,3))
 regs={'rbx':3,'rbp':5,'rsi':6,'rdi':7,'r12':12,'r13':13,'r14':14,'r15':15}
 for sid,start,size,sym in sorted(functions):
  ops=[];frame=0;prolog=0
  instructions=list(cs.disasm(bytes(sec[sid-1]['data'][start:start+size]),start))
  for ins in instructions:
   if ins.mnemonic.startswith('j') or ins.mnemonic in ('call','ret'):break
   end=ins.address+ins.size-start
   if ins.mnemonic=='push':
    reg=ins.op_str;frame+=8;prolog=end
    ops.append(bytes([end,(regs[reg]<<4) if reg in regs else 2]))
   elif ins.mnemonic=='sub' and ins.op_str.startswith('rsp, '):
    amount=int(ins.op_str.split(', ')[1],0);assert amount%8==0 and amount>0
    frame+=amount;prolog=end
    ops.append(bytes([end,2|(((amount-8)//8)<<4)]) if amount<=128 else bytes([end,1])+struct.pack('<H',amount//8))
   elif ins.mnemonic in ('mov','lea','and') and ins.op_str.startswith('rsp,'):raise ValueError('unsupported dynamic stack')
  assert frame<4096 and prolog<256,(start,frame)
  codes=b''.join(reversed(ops));assert len(codes)//2<256
  offset=len(xdata);xdata+=bytes([1,prolog,len(codes)//2,0])+codes
  xdata+=b'\0'*((-len(xdata))%4)
  o=len(pdata);pdata+=struct.pack('<III',0,size,offset)
  pr.extend([(o,sym,3),(o+4,sym,3),(o+8,xsym,3)])
 sec.extend([{'name':'.xdata','data':xdata,'size':len(xdata),'flags':0x40300040,'relocs':[],'bss':False},{'name':'.pdata','data':pdata,'size':len(pdata),'flags':0x40300040,'relocs':pr,'bss':False}])
 strtab=bytearray(b'\0'*4)
 def lname(name,section=False):
  data=name.encode()
  if len(data)<=8:return data.ljust(8,b'\0')
  pos=len(strtab);strtab.extend(data+b'\0')
  return (('/'+str(pos)).encode().ljust(8,b'\0') if section else struct.pack('<II',0,pos))
 out=bytearray(20+40*len(sec));headers=[]
 for s in sec:
  rawoff=0
  if s['data']:
   rawoff=len(out);out+=s['data'];out+=b'\0'*((-len(out))%4)
  relocoff=len(out) if s['relocs'] else 0
  for pos,sym,typ in s['relocs']:out+=struct.pack('<IIH',pos,sym,typ)
  headers.append(struct.pack('<8sIIIIIIHHI',lname(s['name'],True),0,0,s['size'],rawoff,relocoff,0,len(s['relocs']),0,s['flags']))
 symoff=len(out)
 for name,value,sid,typ,storage in syms:out+=struct.pack('<8sIhHBB',lname(name),value,sid,typ,storage,0)
 struct.pack_into('<I',strtab,0,len(strtab));out+=strtab
 struct.pack_into('<HHIIIHH',out,0,0x8664,len(sec),0,symoff,len(syms),0,0)
 for i,h in enumerate(headers):out[20+i*40:60+i*40]=h
 Path(dst).write_bytes(out)

if __name__=='__main__':convert(sys.argv[1],sys.argv[2])
