#include "winapi.h"
#include "patterns.h"

static INIT_ONCE once;
static HMODULE self_module, real_module;
static int patch_status, selected, have_cache;
static void *real_create, *real_unload, *real_class, *real_register, *real_unregister, *real_joystick;
static BYTE *growth_memory;
static WCHAR folder[1024], marker[1200], logfile[1200], cachefile[1200];
static WCHAR cached_config[1200], actual_config[1200], modfile[1200];
static BYTE ini_data[1048576];
static int make_paths(void);
static int read_cache(void);
static int mod_selected(const WCHAR *path);
static int mod_present(void);
static int write_data(const WCHAR*,const void*,DWORD);

static int equal(const BYTE *a,const BYTE*b,SIZE_T n){SIZE_T i;for(i=0;i<n;i++)if(a[i]!=b[i])return 0;return 1;}
static void copy(BYTE*a,const BYTE*b,SIZE_T n){SIZE_T i;for(i=0;i<n;i++)a[i]=b[i];}
static DWORD u32(const BYTE *p){return *(const DWORD*)p;}
static unsigned short u16(const BYTE *p){return *(const unsigned short*)p;}

/* Runs before XCom2.exe's entry point. No DLL loads, user interface, threads,
   CRT, registry work, or waits inside DllMain. */
static int apply_patches(int enable){
    BYTE *base=(BYTE*)CALL(GetModuleHandleW)(0);
    DWORD pe,size,old_growth=0,old_guard=0,tmp;
    int growth_old, guard_old;
    BYTE jump[19];
    if(!base||u16(base)!=0x5a4d)return -1;
    pe=u32(base+0x3c);
    if(pe>0x1000||u32(base+pe)!=0x4550||u16(base+pe+4)!=0x8664||u16(base+pe+24)!=0x20b)return -1;
    size=u32(base+pe+24+56);
    if(u32(base+pe+8)!=0x621562fa||(size!=0x20c7000&&size!=0x20c8000))return -1;
    growth_old=equal(base+0xbc182,growth_original,sizeof(growth_original));
    if(!growth_old && !(size==0x20c8000 && equal(base+0xbc182,growth_r1,sizeof(growth_r1)) && equal(base+0x20c7000,growth_stub,sizeof(growth_stub))))return -1;
    guard_old=equal(base+0xccc660,guard_original,sizeof(guard_original));
    if(!guard_old&&!equal(base+0xccc660,guard_fixed,sizeof(guard_fixed)))return -1;
    if(!enable){
        /* Known older disk patches are neutralized in memory while unchecked.
           Unknown builds are left alone. No executable file is written. */
        if(!growth_old&&!CALL(VirtualProtect)(base+0xbc182,19,0x40,&old_growth))return -2;
        if(!guard_old&&!CALL(VirtualProtect)(base+0xccc660,sizeof(guard_original),0x40,&old_guard)){
            if(!growth_old)CALL(VirtualProtect)(base+0xbc182,19,old_growth,&tmp);
            return -2;
        }
        if(!growth_old)copy(base+0xbc182,growth_original,19);
        if(!guard_old)copy(base+0xccc660,guard_original,sizeof(guard_original));
        if(!growth_old&&(!CALL(FlushInstructionCache)((HANDLE)-1,base+0xbc182,19)||!CALL(VirtualProtect)(base+0xbc182,19,old_growth,&tmp)))return -3;
        if(!guard_old&&(!CALL(FlushInstructionCache)((HANDLE)-1,base+0xccc660,sizeof(guard_original))||!CALL(VirtualProtect)(base+0xccc660,sizeof(guard_original),old_guard,&tmp)))return -3;
        return 0;
    }
    if(growth_old){
        growth_memory=CALL(VirtualAlloc)(0,4096,0x3000,0x04);
        if(!growth_memory)return -2;
        copy(growth_memory,growth_stub,sizeof(growth_stub));
        if(!CALL(VirtualProtect)(growth_memory,4096,0x20,&tmp)||!CALL(FlushInstructionCache)((HANDLE)-1,growth_memory,sizeof(growth_stub))){CALL(VirtualFree)(growth_memory,0,0x8000);growth_memory=0;return -2;}
        if(!CALL(VirtualProtect)(base+0xbc182,19,0x40,&old_growth)){CALL(VirtualFree)(growth_memory,0,0x8000);growth_memory=0;return -2;}
    }
    if(guard_old&&!CALL(VirtualProtect)(base+0xccc660,sizeof(guard_fixed),0x40,&old_guard)){
        if(growth_old){CALL(VirtualProtect)(base+0xbc182,19,old_growth,&tmp);CALL(VirtualFree)(growth_memory,0,0x8000);growth_memory=0;}
        return -2;
    }
    if(growth_old){
        SIZE_T i;for(i=0;i<19;i++)jump[i]=0x90;
        jump[0]=0xff;jump[1]=0x25;jump[2]=jump[3]=jump[4]=jump[5]=0;
        *(SIZE_T*)(jump+6)=(SIZE_T)growth_memory;
        copy(base+0xbc182,jump,19);
    }
    if(guard_old)copy(base+0xccc660,guard_fixed,sizeof(guard_fixed));
    /* The game has not entered its own code yet. Flush before its first use. */
    if(growth_old&&!CALL(FlushInstructionCache)((HANDLE)-1,base+0xbc182,19))return -3;
    if(guard_old&&!CALL(FlushInstructionCache)((HANDLE)-1,base+0xccc660,sizeof(guard_fixed)))return -3;
    if(growth_old&&!CALL(VirtualProtect)(base+0xbc182,19,old_growth,&tmp))return -3;
    if(guard_old&&!CALL(VirtualProtect)(base+0xccc660,sizeof(guard_fixed),old_guard,&tmp))return -3;
    if(!equal(base+0xccc660,guard_fixed,sizeof(guard_fixed)))return -3;
    if(growth_old&&!equal(base+0xbc182,jump,19))return -3;
    return 1;
}

BOOL DllMain(HMODULE module,DWORD reason,void *reserved){
    (void)reserved;
    if(reason==1){
        self_module=module;CALL(DisableThreadLibraryCalls)(module);
        if(make_paths())have_cache=read_cache();
        selected=have_cache&&mod_present()&&mod_selected(cached_config);
        patch_status=apply_patches(selected);
        /* Unknown executables are allowed through only while disabled. */
        if(!selected&&patch_status==-1)patch_status=0;
    }
    return 1;
}

static SIZE_T wlen(const WCHAR*s){SIZE_T n=0;while(s[n])n++;return n;}
static int append(WCHAR *dst,SIZE_T cap,const WCHAR *src){SIZE_T a=wlen(dst),b=wlen(src),i;if(a+b>=cap)return 0;for(i=0;i<=b;i++)dst[a+i]=src[i];return 1;}
static int write_data(const WCHAR *path,const void *text,DWORD n){
    HANDLE f;DWORD count=0;
    f=CALL(CreateFileW)(path,0x40000000,1,0,2,0x80,0);
    if(f==(HANDLE)-1)return 0;
    BOOL ok=CALL(WriteFile)(f,text,n,&count,0);CALL(CloseHandle)(f);return ok&&count==n;
}
static int write_text(const WCHAR *path,const char *text){DWORD n=0;while(text[n])n++;return write_data(path,text,n);}
static DWORD read_data(const WCHAR *path,void *data,DWORD cap){
    HANDLE f=CALL(CreateFileW)(path,0x80000000,7,0,3,0x80,0);DWORD n=0;BOOL ok;
    if(f==(HANDLE)-1)return 0;
    ok=CALL(ReadFile)(f,data,cap,&n,0);CALL(CloseHandle)(f);
    return ok&&n<cap?n:0;
}
static int read_cache(void){
    DWORD n=read_data(cachefile,cached_config,sizeof(cached_config));SIZE_T i;
    if(n<4||(n&1)||cached_config[n/2-1])return 0;
    for(i=0;i<n/2-1;i++)if(!cached_config[i])return 0;
    return 1;
}
static int ascii_equal(const char *a,const char *b){
    unsigned int x,y;
    do{x=(BYTE)*a++;y=(BYTE)*b++;if(x>='A'&&x<='Z')x+=32;if(y>='A'&&y<='Z')y+=32;if(x!=y)return 0;}while(x);
    return 1;
}
static char *trim(char *s){SIZE_T n;while(*s==' '||*s=='\t')s++;n=0;while(s[n])n++;while(n&&(s[n-1]==' '||s[n-1]=='\t'||s[n-1]=='\r'))s[--n]=0;return s;}
static int mod_selected(const WCHAR *path){
    DWORD n=read_data(path,ini_data,sizeof(ini_data)),i=0,j=0,step=1;int endian=0,section=0,active=0,overflow=0;
    char line[1024],*p,*key,*value;unsigned int c;
    if(!n)return 0;
    if(n>=2&&ini_data[0]==255&&ini_data[1]==254){i=2;step=2;}
    else if(n>=2&&ini_data[0]==254&&ini_data[1]==255){i=2;step=2;endian=1;}
    else if(n>=3&&ini_data[0]==239&&ini_data[1]==187&&ini_data[2]==191)i=3;
    if(step==2&&(n&1))return 0;
    while(i<=n){
        if(i==n){c='\n';i++;}else{c=ini_data[i];if(step==2)c=endian?(c*256+ini_data[i+1]):(c+ini_data[i+1]*256);i+=step;}
        if(c!='\n'){if(j<sizeof(line)-1)line[j++]=c<128?(char)c:'?';else overflow=1;continue;}
        if(overflow)return 0;
        line[j]=0;j=0;p=trim(line);
        if(*p==';'||*p=='#'||!*p)continue;
        if(*p=='['){section=ascii_equal(p,"[Engine.XComModOptions]");continue;}
        if(!section)continue;
        key=p;while(*p&&*p!='=')p++;if(!*p)continue;*p++=0;key=trim(key);value=trim(p);
        j=0;while(value[j])j++;
        if(j>=2&&value[0]=='"'&&value[j-1]=='"'){value[j-1]=0;value++;}
        j=0;
        if(ascii_equal(key,"!ActiveMods")){active=0;continue;}
        if(!ascii_equal(value,"WotCNativeCrashFix"))continue;
        if(ascii_equal(key,"ActiveMods")||ascii_equal(key,"+ActiveMods")||ascii_equal(key,".ActiveMods"))active=1;
        if(ascii_equal(key,"-ActiveMods"))active=0;
    }
    return active;
}
static int mod_present(void){
    DWORD n=CALL(GetModuleFileNameW)(self_module,modfile,1200);int levels=3;
    if(!n||n>=1200)return 0;
    while(n&&levels){if(modfile[--n]=='\\')levels--;}
    if(levels)return 0;
    modfile[n]=0;
    if(!append(modfile,1200,W("\\XComGame\\Mods\\WotCNativeCrashFix\\WotCNativeCrashFix.XComMod")))return 0;
    return CALL(GetFileAttributesW)(modfile)!=0xffffffffU;
}
static void fatal(const WCHAR *text){
    if(logfile[0])write_text(logfile,"FAILED: initialization or forwarding failed. See the on-screen error.\r\n");
    CALL(MessageBoxW)(0,text,W("XCOM 2 Native Auto-Init - failed"),0x10);
    CALL(ExitProcess)(1);
}
static int make_paths(void){
    WCHAR exe[1024],hex[17];SIZE_T hash=14695981039346656037ULL,i;DWORD n;
    static const WCHAR digits[]=u"0123456789abcdef";
    n=CALL(GetEnvironmentVariableW)(W("LOCALAPPDATA"),folder,1024);
    if(!n||n>=1024)return 0;
    if(!append(folder,1024,W("\\XCOM2NativeCrashFix")))return 0;
    CALL(CreateDirectoryW)(folder,0);
    n=CALL(GetModuleFileNameW)(0,exe,1024);if(!n||n>=1024)return 0;
    for(i=0;i<n;i++){hash^=exe[i];hash*=1099511628211ULL;}
    for(i=0;i<16;i++){hex[i]=digits[(hash>>((15-i)*4))&15];}
    hex[16]=0;
    marker[0]=logfile[0]=cachefile[0]=0;
    return append(cachefile,1200,folder)&&append(cachefile,1200,W("\\"))&&append(cachefile,1200,hex)&&append(cachefile,1200,W("-v3.config-path"))&&append(marker,1200,folder)&&append(marker,1200,W("\\"))&&append(marker,1200,hex)&&append(marker,1200,W("-v3.0.complete"))&&append(logfile,1200,folder)&&append(logfile,1200,W("\\"))&&append(logfile,1200,hex)&&append(logfile,1200,W("-startup.log"));
}
/* Invoked by a normal DirectInput call, after the Windows loader has finished.
   Dynamic DLL loading, logging and the restart prompt stay OUTSIDE DllMain. */
static BOOL ready(INIT_ONCE *unused,void *parameter,void **context){
    WCHAR system_dll[1024];DWORD n;HMODULE shell;void *get_documents;int now_selected,path_changed;
    (void)unused;(void)parameter;(void)context;
    if(!make_paths())fatal(W("Cannot create the per-user setup paths. No restart-complete marker was saved."));
    if(selected&&patch_status==-1)fatal(W("This executable or its instruction bytes are not supported. The automatic fixes were NOT applied. Close the game and remove this dinput8.dll to use the unmodified launch path."));
    if(patch_status<0)fatal(W("Automatic native patch initialization failed. The game will close rather than continue with an unverified patch. See the included README for removal."));
    n=CALL(GetSystemDirectoryW)(system_dll,1024);
    if(!n||n>=1024||!append(system_dll,1024,W("\\dinput8.dll")))fatal(W("Could not locate Windows' original DirectInput DLL."));
    real_module=CALL(LoadLibraryExW)(system_dll,0,0x800);
    if(!real_module||real_module==self_module)fatal(W("Could not load Windows' original DirectInput DLL."));
    real_create=CALL(GetProcAddress)(real_module,"DirectInput8Create");
    real_unload=CALL(GetProcAddress)(real_module,"DllCanUnloadNow");
    real_class=CALL(GetProcAddress)(real_module,"DllGetClassObject");
    real_register=CALL(GetProcAddress)(real_module,"DllRegisterServer");
    real_unregister=CALL(GetProcAddress)(real_module,"DllUnregisterServer");
    real_joystick=CALL(GetProcAddress)(real_module,"GetdfDIJoystick");
    if(!real_create)fatal(W("Windows DirectInput8Create could not be resolved."));
    /* Resolve Windows' real Documents folder here, outside loader lock.
       Cache its path only, NEVER the enabled state. Each process reads AML again. */
    n=CALL(GetSystemDirectoryW)(system_dll,1024);
    if(!n||n>=1024||!append(system_dll,1024,W("\\shell32.dll")))fatal(W("Cannot locate the Windows Documents-folder service."));
    shell=CALL(LoadLibraryExW)(system_dll,0,0x800);
    get_documents=shell?CALL(GetProcAddress)(shell,"SHGetFolderPathW"):0;
    if(!get_documents||((HRESULT(*)(HANDLE,int,HANDLE,DWORD,WCHAR*))get_documents)(0,5,0,0,actual_config)!=0)fatal(W("Cannot resolve your Documents folder. The game will close before loading a save."));
    if(!append(actual_config,1200,W("\\My Games\\XCOM2 War of the Chosen\\XComGame\\Config\\XComModOptions.ini")))fatal(W("The mod-options path is too long."));
    path_changed=!have_cache||!equal((const BYTE*)cached_config,(const BYTE*)actual_config,(wlen(actual_config)+1)*2);
    now_selected=mod_present()&&mod_selected(actual_config);
    if(path_changed&&!write_data(cachefile,actual_config,(DWORD)((wlen(actual_config)+1)*2)))fatal(W("Cannot save the startup configuration path."));
    if(path_changed&&(now_selected||selected)){
        /* Never patch late, after the game's threads may have started. */
        write_text(logfile,"First-use configuration initialized. Restart required for pre-entry native initialization.\r\n");
        CALL(MessageBoxW)(0,W("WotC Native Crash Fix has initialized its startup configuration.\n\nRestart XCOM now so the enabled fixes can load before the game starts. XCOM will close when you press OK. Start it again through AML with the mod checked."),W("WotC Native Crash Fix - restart required"),0x40);
        if(!write_text(marker,"v3.0: first-use restart requested; every later enabled launch still verifies both patches.\r\n"))fatal(W("Cannot save the restart marker."));
        CALL(ExitProcess)(0);return 1;
    }
    if(now_selected!=selected)fatal(W("The active mod list changed during startup. Restart XCOM through AML to use the current selection."));
    if(!selected){write_text(logfile,"WotCNativeCrashFix disabled: neither fix active on supported builds. System DirectInput forwarding ready.\r\n");return 1;}
    if(!write_text(logfile,"WotCNativeCrashFix enabled: both native fixes verified before the game entry point; active for this entire process, including return to Avenger.\r\n"))fatal(W("Cannot write the initialization log."));
    if(CALL(GetFileAttributesW)(marker)==0xffffffffU){
        CALL(MessageBoxW)(0,W("Both native fixes initialized from your enabled AML mod selection.\n\nPlease restart XCOM once. XCOM will close when you press OK; launch it again through AML with the mod checked."),W("WotC Native Crash Fix - first-launch restart"),0x40);
        if(!write_text(marker,"v3.0: both fixes verified; first-launch restart requested.\r\n"))fatal(W("Cannot save the restart marker."));
        CALL(ExitProcess)(0);
    }
    return 1;
}
static void ensure_ready(void){if(!CALL(InitOnceExecuteOnce)(&once,ready,0,0))fatal(W("DirectInput startup initialization failed."));}
HRESULT DirectInput8Create(HANDLE h,DWORD version,const void *iid,void **output,void *outer){ensure_ready();return ((HRESULT(*)(HANDLE,DWORD,const void*,void**,void*))real_create)(h,version,iid,output,outer);}
HRESULT DllCanUnloadNow(void){ensure_ready();return real_unload?((HRESULT(*)(void))real_unload)():1;}
HRESULT DllGetClassObject(const void*a,const void*b,void**c){ensure_ready();return real_class?((HRESULT(*)(const void*,const void*,void**))real_class)(a,b,c):(HRESULT)0x80004005;}
HRESULT DllRegisterServer(void){ensure_ready();return real_register?((HRESULT(*)(void))real_register)():(HRESULT)0x80004005;}
HRESULT DllUnregisterServer(void){ensure_ready();return real_unregister?((HRESULT(*)(void))real_unregister)():(HRESULT)0x80004005;}
void *GetdfDIJoystick(void){ensure_ready();return real_joystick?((void*(*)(void))real_joystick)():0;}

/* Force a base-relocation entry for Windows ASLR. */
void * const NativeAutoInitAnchor = (void*)&DllMain;
