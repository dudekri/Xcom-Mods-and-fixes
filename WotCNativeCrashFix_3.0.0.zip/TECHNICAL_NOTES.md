# Implementation and limits

The .XComMod basename is the activation ID: `WotCNativeCrashFix`.
AML writes its selected IDs as `ActiveMods` entries in the user configuration
`Documents/My Games/XCOM2 War of the Chosen/XComGame/Config/XComModOptions.ini`.
The bootstrap reads that file afresh at process attach. It does not infer
activation from the mere presence of a mod folder, cached marker, or default INI.
Both an active ID and the installed descriptor at the supplied local Mods path
are required. Relocating this mod folder elsewhere is not supported by this build.
The INI parser supports UTF-8, UTF-8 BOM, UTF-16 LE/BE, case-insensitive exact IDs,
quoted IDs, sections, comments, and UE array add/remove/clear operators. Missing,
oversized, or unreadable selection files are treated as disabled.

The cached UTF-16 file stores only the config path, not activation. Windows'
SHGetFolderPathW (CSIDL_PERSONAL) resolves Documents outside DllMain. Changes to
that path trigger a restart before gameplay. A fresh enabled setup exits after
recording the path and requesting restart, so patches are never applied after
application threads have started. All code writes occur at process attach.
No shell, COM, registry, User32, dynamic library loading, thread creation, or
wait is called inside DllMain. It uses Kernel32 file I/O, environment/path access,
memory operations and local parsing. The normal DirectInput entry points use
InitOnceExecuteOnce for system-DLL forwarding, logging and restart UI.

The DLL forwards DirectInput calls to the absolute System32 dinput8.dll, loaded
with LOAD_LIBRARY_SEARCH_SYSTEM32. The fifth DirectInput8Create argument is
preserved according to the Windows x64 ABI. No gameplay script package or SDK
compiler is required; the selectable mod descriptor supplies AML's enable ID.
The descriptor does not itself load the native DLL: the application-local
DirectInput import provides the bootstrap. This native file is indispensable
for this implementation, and remains loaded as a forwarding proxy when off.

Enabled: growth RVA 0xBC182 uses a leaf stub implementing
min(NewCount + floor(3*NewCount/8) + 16, INT32_MAX) with wide intermediates.
Known R1 .hqfix stubs are retained. The native IsPlayerControlled function at
RVA 0xCCC660 receives the existing 1.1 missing-lookup/cast-null guards, returning
false through its original epilogue. All expected instruction sequences are
checked before changes. Disabled: known R1/1.1 instructions are restored to the
original in memory; no disk bytes change. Unknown builds are never patched.

Build from this directory: `python3 source/build.py`. Requirements: Linux GNU
GCC and binutils with i386pep output, Python and capstone. Only the resulting
`build/dinput8.dll` is deployable. The dummy import-provider DLLs made during
build must never be installed. The ELF-to-COFF converter preserves relocation
addends and emits Windows unwind tables for compiler-generated fixed prologues.
The DLL has PE unwind data, ASLR relocations and NX compatibility.

Run lifecycle tests: `python3 source/test_loader.py ORIGINAL_XCom2.exe COMBINED_1.1_XCom2.exe`
(requires Python pefile, unicorn and capstone). Tests execute actual compiled
DLL instructions at two image bases, with mocked API boundaries; they do not
verify the Windows loader or any real game session.

Primary implementation references:
- https://github.com/X2CommunityCore/xcom2-launcher/blob/master/xcom2-launcher/xcom2-launcher/Classes/XCOM/XComEnvironment.cs
- https://github.com/X2CommunityCore/xcom2-launcher/blob/master/xcom2-launcher/xcom2-launcher/Classes/XCOM/Xcom2Env.cs
- https://x2communitycore.github.io/X2WOTCCommunityHighlander/misc/ModDependencyCheck/
- https://learn.microsoft.com/en-us/windows/win32/dlls/dynamic-link-library-best-practices
- https://learn.microsoft.com/en-us/windows/win32/dlls/dynamic-link-library-search-order
