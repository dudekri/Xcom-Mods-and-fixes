@echo off
setlocal
set "WOTC_NATIVE_INSTALL_SCRIPT=%~dp0Install.ps1"
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "try { Unblock-File -LiteralPath $env:WOTC_NATIVE_INSTALL_SCRIPT -ErrorAction Stop; & $env:WOTC_NATIVE_INSTALL_SCRIPT; exit $LASTEXITCODE } catch { Write-Host $_ -ForegroundColor Red; exit 1 }"
set "installResult=%ERRORLEVEL%"
echo.
pause
exit /b %installResult%
