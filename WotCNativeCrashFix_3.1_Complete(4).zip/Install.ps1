param([string]$GameDir)
$ErrorActionPreference = 'Stop'
function Get-Hash([string]$Path) { (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant() }
function Resolve-Game([string]$Path) {
    if (!$Path) { return }
    $Path = $Path.Trim().Trim('"')
    $candidates = @((Join-Path $Path 'XCom2-WarOfTheChosen'), $Path, (Join-Path $Path '..\..'))
    foreach ($candidatePath in $candidates) {
        $candidate = [IO.Path]::GetFullPath($candidatePath).TrimEnd('\','/')
        # Never mistake the base game's Binaries folder for WOTC.
        if ((Split-Path $candidate -Leaf) -ine 'XCom2-WarOfTheChosen') { continue }
        if (Test-Path -LiteralPath (Join-Path $candidate 'Binaries\Win64\XCom2.exe')) { return $candidate }
    }
}
try {
    if (Get-Process -Name XCom2 -ErrorAction SilentlyContinue) { throw 'Close XCOM 2 before installing.' }
    $payload = Join-Path $PSScriptRoot 'XCom2-WarOfTheChosen'
    $relativeFiles = @('Binaries\Win64\dinput8.dll', 'XComGame\Mods\WotCNativeCrashFix\WotCNativeCrashFix.XComMod', 'XComGame\Mods\WotCNativeCrashFix\Config\XComNativeCrashFix.ini')
    $manifest = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'installer-files.json') -Raw | ConvertFrom-Json
    foreach ($rel in $relativeFiles) {
        if ((Get-Hash (Join-Path $payload $rel)) -ne $manifest.PSObject.Properties[$rel].Value) { throw "Package integrity check failed: $rel. Extract the complete ZIP again." }
    }
    $game = Resolve-Game $GameDir
    if ($GameDir -and !$game) { throw 'The supplied folder does not contain War of the Chosen.' }
    if (!$game) {
        $roots = @()
        foreach ($key in @('HKCU:\Software\Valve\Steam','HKLM:\SOFTWARE\WOW6432Node\Valve\Steam','HKLM:\SOFTWARE\Valve\Steam')) {
            if (Test-Path $key) {
                $entry = Get-ItemProperty $key
                if ($entry.SteamPath) { $roots += $entry.SteamPath }
                if ($entry.InstallPath) { $roots += $entry.InstallPath }
            }
        }
        if (${env:ProgramFiles(x86)}) { $roots += (Join-Path ${env:ProgramFiles(x86)} 'Steam') }
        foreach ($steamRoot in @($roots)) {
            $vdf = Join-Path $steamRoot 'steamapps\libraryfolders.vdf'
            if (Test-Path -LiteralPath $vdf) {
                foreach ($match in [regex]::Matches((Get-Content -LiteralPath $vdf -Raw), '"path"\s+"([^"]+)"')) {
                    $roots += $match.Groups[1].Value.Replace('\\','\')
                }
            }
        }
        $seen = [Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
        $found = @($roots | ForEach-Object {
            $resolved = Resolve-Game (Join-Path $_ 'steamapps\common\XCOM 2')
            if ($resolved -and $seen.Add($resolved)) { $resolved }
        })
        if ($found.Count -eq 1) { $game = $found[0] }
        else {
            if ($found.Count -gt 1) { Write-Host "Multiple installations found:`n$($found -join "`n")" }
            $game = Resolve-Game (Read-Host 'Paste the XCOM 2 or XCom2-WarOfTheChosen installation folder')
            if (!$game) { throw 'War of the Chosen was not found in that folder. No files changed.' }
        }
    }
    Write-Host "Installing WotC Native Crash Fix 3.1 to: $game"
    $exe = Join-Path $game 'Binaries\Win64\XCom2.exe'
    # Check the PE build before installing. The native loader also validates each
    # repair site and recognizes supported legacy patches before activation.
    $stream = [IO.File]::OpenRead($exe)
    $reader = New-Object IO.BinaryReader($stream)
    try {
        if ($reader.ReadUInt16() -ne 0x5a4d) { throw 'Unsupported executable.' }
        $stream.Position = 0x3c; $pe = $reader.ReadUInt32()
        if ($pe -gt 0x1000 -or ($pe + 84) -gt $stream.Length) { throw 'Unsupported PE header.' }
        $stream.Position = $pe
        if ($reader.ReadUInt32() -ne 0x4550 -or $reader.ReadUInt16() -ne 0x8664) { throw 'This requires the Windows 64-bit WOTC executable.' }
        $stream.Position = $pe + 8
        if ($reader.ReadUInt32() -ne 0x621562fa) { throw 'Unsupported executable build. No files changed.' }
        $stream.Position = $pe + 24
        if ($reader.ReadUInt16() -ne 0x20b) { throw 'Unsupported executable format.' }
        $stream.Position = $pe + 80; $imageSize = $reader.ReadUInt32()
        if ($imageSize -ne 0x20c7000 -and $imageSize -ne 0x20c8000) { throw 'Unsupported executable image size.' }
    } finally { $reader.Dispose() }
    $dll = Join-Path $game $relativeFiles[0]
    $newHash = $manifest.PSObject.Properties[$relativeFiles[0]].Value
    if (Test-Path -LiteralPath $dll) {
        $oldHash = Get-Hash $dll
        if ($oldHash -notin @($newHash,'323f96c47ad73d3834b54397aa864fd5024f8640227d95505a9ba7111840b204')) {
            throw 'Existing dinput8.dll is not the recognized 3.0 or 3.1 release. It was not overwritten. Do not remove another mod DLL.'
        }
    }
    $different = @($relativeFiles | Where-Object {
        $target = Join-Path $game $_
        !(Test-Path -LiteralPath $target) -or (Get-Hash $target) -ne $manifest.PSObject.Properties[$_].Value
    })
    if ($different.Count -eq 0) { Write-Host 'All 3.1 files are already installed. Enable WotC Native Crash Fix in AML.'; exit 0 }
    $backup = Join-Path $game ('NativeCrashFix-Backups\' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '-' + [guid]::NewGuid().ToString('N').Substring(0,8))
    New-Item -ItemType Directory -Path $backup -Force | Out-Null
    $records = @()
    # Complete backups before replacing any destination file.
    foreach ($rel in $different) {
        $target = Join-Path $game $rel
        $existed = Test-Path -LiteralPath $target
        if ($existed) {
            $saved = Join-Path $backup $rel
            New-Item -ItemType Directory -Path (Split-Path $saved) -Force | Out-Null
            Copy-Item -LiteralPath $target -Destination $saved
            if ((Get-Hash $saved) -ne (Get-Hash $target)) { throw 'Backup verification failed; no installed files replaced.' }
        }
        $records += [pscustomobject]@{ Path=$rel; Existed=$existed }
    }
    $records | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $backup 'files.json') -Encoding UTF8
    $touched = @()
    try {
        foreach ($record in $records) {
            $target = Join-Path $game $record.Path
            New-Item -ItemType Directory -Path (Split-Path $target) -Force | Out-Null
            $touched += $record
            Copy-Item -LiteralPath (Join-Path $payload $record.Path) -Destination $target -Force
            if ((Get-Hash $target) -ne $manifest.PSObject.Properties[$record.Path].Value) { throw "Installed file verification failed: $($record.Path)" }
        }
    } catch {
        $failure = $_
        foreach ($record in $touched) {
            $target = Join-Path $game $record.Path
            if ($record.Existed) { Copy-Item -LiteralPath (Join-Path $backup $record.Path) -Destination $target -Force }
            elseif (Test-Path -LiteralPath $target) { Remove-Item -LiteralPath $target -Force }
        }
        throw "Installation failed; replaced files rolled back. $failure"
    }
    Write-Host "Installed and verified. Backup: $backup"
    Write-Host 'Refresh/restart AML, enable WotC Native Crash Fix, then launch normally.'
    Write-Host 'If first-use setup asks for a restart, launch again with the mod enabled.'
    Write-Host 'XCom2.exe and save files were not modified.'
} catch {
    Write-Host "INSTALL FAILED: $_" -ForegroundColor Red
    Write-Host 'For an access-denied error, right-click INSTALL.cmd and choose Run as administrator.'
    exit 1
}
