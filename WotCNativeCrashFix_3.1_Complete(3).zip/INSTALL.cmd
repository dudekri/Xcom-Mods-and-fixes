@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install.ps1" %*
set "installResult=%ERRORLEVEL%"
echo.
pause
exit /b %installResult%
