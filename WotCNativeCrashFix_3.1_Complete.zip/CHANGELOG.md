# 3.1 complete package

- Retains the array-growth repair and Avenger IsPlayerControlled null guard.
- Adds the duplication archive reader/writer, seek and end-check repair for
  buffers crossing signed 2 GiB, bounded at 4 GiB minus 64 KiB.
- Bundles the AML mod descriptor/configuration for fresh installations.
- Updates visible mod metadata to 3.1.0.
- Uses the established folder-copy installation for both fresh installs and
  upgrades; removes the installation-specific candidate installer requirement.
- Preserves the original 3.1 native DLL and source without rebuilding them.
- Includes installation, rollback, compatibility, limitations and source instructions.
