# WotC Native Crash Fix 3.1 — complete package

Includes the earlier array-growth and Avenger player-lookup repairs plus the
3.1 large-save duplication-buffer fix. This replaces the 3.0 download; it is
not an additional mod. Keep the same WotCNativeCrashFix entry enabled in AML.

## Install or upgrade

1. Close XCOM 2. Extract this ZIP completely.
2. Open your XCOM 2 installation folder. In Steam, use the game's Manage >
   Browse local files. Locate `XCom2-WarOfTheChosen` inside it.
3. If upgrading this fix, back up the existing
   `XCom2-WarOfTheChosen/Binaries/Win64/dinput8.dll` somewhere outside the game
   folder. If an unrelated mod owns that DLL, do not overwrite it: DLL chaining
   is not supported. A fresh installation does not require an existing DLL.
4. Copy the included `XCom2-WarOfTheChosen` folder into the XCOM 2 installation
   folder and merge folders. Replace this fix's existing files when asked.
   Do not place the whole folder inside another `XCom2-WarOfTheChosen` folder.
5. In AML, refresh the mod list and enable **WotC Native Crash Fix**. If missing,
   add `XCom2-WarOfTheChosen/XComGame/Mods` to AML's mod directories.
6. Launch normally through AML. If first-use setup requests a restart,
   acknowledge it and launch again with the mod enabled. Existing initialized
   installations normally do not need this setup restart.

Final file locations, relative to the XCOM 2 installation folder:

- `XCom2-WarOfTheChosen/Binaries/Win64/dinput8.dll`
- `XCom2-WarOfTheChosen/XComGame/Mods/WotCNativeCrashFix/WotCNativeCrashFix.XComMod`
- `XCom2-WarOfTheChosen/XComGame/Mods/WotCNativeCrashFix/Config/XComNativeCrashFix.ini`

No SDK compilation, custom launcher, installer command or save conversion is
required. This package does not modify the executable or save files on disk.
A Workshop subscription alone cannot install the native DLL beside XCom2.exe.

## Compatibility and scope

The native loader verifies the supported AMD64 WOTC executable build and the
specific patch sites before activation. The supported original executable has
PE timestamp `0x621562fa` and SHA-256
`d830aad0bdc5aea35e3a62f51cbd7f0c22b4d297ac3c02cdea37a746fde110ae`.
The known earlier R1 and combined 1.1 patched variants are also recognized.
Unknown/incompatible enabled builds are rejected; do not bypass the checks.
Compatibility with every storefront or executable revision is not established.

The 3.1 DLL is byte-for-byte the October 14 large-save candidate supplied and
tested by the project owner. Its original custom installer required one exact
existing DLL and executable. That installation-specific script is deliberately
not used in this complete folder-copy release; the DLL's existing runtime
compatibility checks remain unchanged.

The large-save repair uses unsigned 32-bit duplication-buffer positions and
64-bit arithmetic for bounds/growth checks. Its ceiling is 4 GiB minus 64 KiB
(4,294,901,760 bytes), not unlimited. It does not shrink saves or reduce their
memory requirements. Invalid ranges or allocation failures stop the process.
This does not change the on-disk save format or generic archive classes.

The separate eight-million object-table reserve previously applied to the
project owner's executable is NOT installed by this package. An existing
reserve patch remains in place. Do not describe this package as installing
that separate executable modification or solving every large-save crash.

## Disable, roll back or remove

To disable, uncheck the mod in AML and start a new game process. Toggling AML
while the game is running does not change that process. Recognized older
array-growth/player-lookup disk patches are neutralized in memory while disabled;
other separate executable modifications, including object-table reserve, remain.

To roll back an upgrade, close the game and restore your backed-up DLL and
previous mod metadata files, or reinstall the complete previous release.
To uninstall, close the game, remove this package's dinput8.dll and remove the
WotCNativeCrashFix mod folder. Do not delete another mod's DLL. Uninstalling
this package does not undo older changes made directly to XCom2.exe.

## Diagnostics and testing

Startup log: `%LOCALAPPDATA%/XCOM2NativeCrashFix/<installation-hash>-startup.log`.
The DLL identifies the 3.1 candidate. Large-buffer logs report writer/reader
crossing 2 GiB and reaching the end of a large buffer. These entries alone do
not prove the mission finished loading.

The project owner reported that the affected large save loaded with 3.1.
This repack preserves that DLL unchanged. No Windows launch or fresh-install
playtest was performed while assembling this package. Included validation
reports are inherited from the original build: emulator tests with mocked
Windows APIs/allocator, not broad compatibility certification. The DLL still
uses its original candidate labels internally.

## Source

Complete 3.1 source is in `source/`. On Linux with GCC/binutils, Python,
capstone, pefile and unicorn installed:

```
python3 source/build.py
python3 source/test_loader.py REFERENCE_XCom2.exe INSTALLED_XCom2.exe
python3 source/test_archive.py REFERENCE_XCom2.exe INSTALLED_XCom2.exe
```

Only `build/dinput8.dll` is deployable. Never install the dummy KERNEL32/USER32
DLLs generated to build import libraries. No game executable is redistributed.
