"""Run the compiled Windows x64 DLL at sparse 2/4 GiB boundaries in Unicorn.
Engine heap and memcpy are instrumented boundaries, not real game execution.
"""
import json,struct,sys
from pathlib import Path
scope={'__file__':str(Path(__file__).with_name('test_loader.py'))}
exec(Path(scope['__file__']).read_text().split('\ncases=0')[0],scope)
globals().update({k:v for k,v in scope.items() if k!='__file__'})
ARRAY=STACK+0x1000;AR=STACK+0x2000;SRC=STACK+0x3000;DST=STACK+0x5000;BUF=0x2000000000
class ArchiveSim(Sim):
 def __init__(self,base=0x180000000,active=True):
  super().__init__('r2',base,active=active)
  self.allocations=[];self.transfers=[];self.fail_alloc=False
  self.u.mem_map(B+0x10b000,4096);self.u.mem_map(B+0x115e000,4096)
  self.pages=set()
  for off in [0,0x7ffff000,0x80000000,0x80001000,0xfffef000]:self.page(BUF+off)
  self.boot()
  self.writer=self.q(B+0x138b148);self.reader=self.q(B+0x138b030)
  self.end=self.q(B+0x138b088);self.seek=self.q(B+0x138b090)
 def page(self,addr):
  page=addr&~4095
  if page not in self.pages:self.u.mem_map(page,4096);self.pages.add(page)
 def hook(self,u,a,size,user):
  if a==B+0x10b9e0:
   old,n,align=[self.r(r) for r in [UC_X86_REG_RCX,UC_X86_REG_RDX,UC_X86_REG_R8]]
   assert old in [0,BUF] and align==8 and 0<n<=0xffff0000
   self.allocations.append(n);self.ret(0 if self.fail_alloc else BUF);return
  if a==B+0x115e83a:
   dst,src,n=[self.r(r) for r in [UC_X86_REG_RCX,UC_X86_REG_RDX,UC_X86_REG_R8]]
   assert n<=8192
   self.transfers.append((dst,src,n));u.mem_write(dst,bytes(u.mem_read(src,n)));self.ret(dst);return
  super().hook(u,a,size,user)
 def state(self,pos,num,cap):
  self.u.mem_write(ARRAY,struct.pack('<QII',BUF if cap else 0,num,cap))
  self.u.mem_write(AR+0x98,struct.pack('<QI',ARRAY,pos))
 def pos(self):return struct.unpack('<I',self.u.mem_read(AR+0xa0,4))[0]
 def num(self):return struct.unpack('<I',self.u.mem_read(ARRAY+8,4))[0]
 def call(self,func,args):
  registers=[UC_X86_REG_RBX,UC_X86_REG_RBP,UC_X86_REG_RSI,UC_X86_REG_RDI,UC_X86_REG_R12,UC_X86_REG_R13,UC_X86_REG_R14,UC_X86_REG_R15]
  vals=[0x123400+i for i in range(len(registers))]
  for r,v in zip(registers,vals):self.u.reg_write(r,v)
  value=self.invoke(func,args)
  if self.exit is None:assert [self.r(r) for r in registers]==vals
  return value
results=[]
for base in [0x180000000,0x7ffa12340000]:
 s=ArchiveSim(base)
 assert s.writer!=B+0xff810 and s.reader!=B+0xff7c0
 # Empty buffer growth and byte-exact small roundtrip.
 s.state(0,0,0);payload=bytes(range(256))*4;s.u.mem_write(SRC,payload)
 s.call(s.writer,[AR,SRC,len(payload)]);assert s.pos()==s.num()==len(payload)
 s.call(s.seek,[AR,0]);s.call(s.reader,[AR,DST,len(payload)])
 assert bytes(s.u.mem_read(DST,len(payload)))==payload and s.call(s.end,[AR])==1
 # Read AtEnd must remain false while positive position < unsigned large size.
 s.state(0,0x80000040,0x80000100);assert s.call(s.end,[AR])==0
 # Crossing the exact crash boundary, plus overwrites and unsigned seeks.
 for pos,n in [(0x7ffffffe,4),(0x80000002,4),(0x7ffffff0,64),(0xfffefff0,16)]:
  s.state(pos,pos,pos);payload=bytes((i*29+7)%256 for i in range(n));s.u.mem_write(SRC,payload)
  s.call(s.writer,[AR,SRC,n]);assert s.pos()==s.num()==pos+n
  assert s.transfers[-1][0]==BUF+pos and s.exit is None
  s.call(s.seek,[AR,pos]);assert s.call(s.end,[AR])==0
  s.call(s.reader,[AR,DST,n]);assert bytes(s.u.mem_read(DST,n))==payload
  assert s.call(s.end,[AR])==1
  s.call(s.seek,[AR,pos]);s.call(s.writer,[AR,SRC,n]);assert s.num()==pos+n
 results.append({'dll_base':hex(base),'small_roundtrip':True,'boundary_roundtrips':4,'unsigned_AtEnd':True,'seek_and_overwrite':True,'nonvolatile_registers_preserved':True})
 for label,mode,pos,num,cap,count in [
  ('ceiling','write',0xfffefff0,0xfffefff0,0xffff0000,32),
  ('read_past_end','read',0x80000002,0x80000004,0x80000004,4),
  ('invalid_seek','seek',0,16,32,17),
  ('negative_read','read',0,16,32,0xffffffff),
  ('writer_gap','write',17,16,32,4),
  ('overwrite_past_end','write',14,16,32,4),
  ('allocation_failure','write',0,0,0,4)]:
  s=ArchiveSim(base);s.state(pos,num,cap);s.fail_alloc=label=='allocation_failure'
  if mode=='write':s.call(s.writer,[AR,SRC,count])
  elif mode=='read':s.call(s.reader,[AR,DST,count])
  else:s.call(s.seek,[AR,count])
  assert s.exit==2 and s.messages and not s.transfers,(label,s.exit)
  assert s.pos()==pos and s.num()==num,label
  results.append({'dll_base':hex(base),'guard':label,'stopped_before_copy':True})
 s=ArchiveSim(base,False)
 assert s.writer==B+0xff810 and s.reader==B+0xff7c0
 results.append({'dll_base':hex(base),'disabled_archive_tables_untouched':True})
print(json.dumps({'results':results,'actual_game_load_tested':False,'allocator_and_memcpy':'mocked; sparse address space checks','limit_bytes':0xffff0000},indent=2))
