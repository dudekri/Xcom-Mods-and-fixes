/* Only FDuplicateDataReader/Writer; never change generic TArray or save format.
 * Their ABI is DWORD-sized. Use its unsigned range, reserving 64 KiB at the
 * top for allocator alignment and the -1 archive sentinel. Arithmetic is 64 bit.
 * This is a bounded 4 GiB candidate, not an unlimited/64-bit FArchive conversion.
 */
#define LARGE_LIMIT 0xffff0000ULL
static BYTE *large_base;
static void large_log(const char *text) {
    HANDLE f; DWORD n=0,w=0;
    if(!logfile[0])return;
    while(text[n])n++;
    f=CALL(CreateFileW)(logfile,4,3,0,4,0x80,0);
    if(f==(HANDLE)-1)return;
    CALL(WriteFile)(f,text,n,&w,0);CALL(CloseHandle)(f);
}
static void large_stop(const WCHAR *message) {
    large_log("LargeSave: STOP - archive bounds/allocation check failed; no further archive access.\r\n");
    CALL(MessageBoxW)(0,message,W("WotC Native Crash Fix - large save"),0x10);
    CALL(ExitProcess)(2);
}
static BYTE *large_array(BYTE *ar){return *(BYTE**)(ar+0x98);}
static DWORD large_position(BYTE *ar){return *(DWORD*)(ar+0xa0);}
static void large_write(BYTE *ar,BYTE *src,int count) {
    BYTE *a,*data; DWORD pos,num,cap; SIZE_T end,next;
    if(!src||count<=0)return; /* matches the stock writer */
    a=large_array(ar);pos=large_position(ar);num=*(DWORD*)(a+8);cap=*(DWORD*)(a+12);
    end=(SIZE_T)pos+(DWORD)count;
    if(end>LARGE_LIMIT||pos>num||num>cap||(pos!=num&&end>num)){
        large_stop(W("The temporary duplication archive exceeds this build's 4 GiB minus 64 KiB limit, or its bounds are inconsistent. XCOM will close before writing outside the buffer. The save file has not been edited."));return;
    }
    data=*(BYTE**)a;
    if(end>cap){
        next=end+end*3/8+16;
        if(next>LARGE_LIMIT)next=LARGE_LIMIT;
        data=((BYTE*(*)(BYTE*,DWORD,DWORD))(large_base+0x10b9e0))(data,(DWORD)next,8);
        if(!data){large_stop(W("XCOM could not allocate the temporary large-save buffer. XCOM will close; the save file has not been edited."));return;}
        *(BYTE**)a=data;*(DWORD*)(a+12)=(DWORD)next;
    }
    ((void*(*)(void*,const void*,SIZE_T))(large_base+0x115e83a))(data+(SIZE_T)pos,src,(DWORD)count);
    if(end>num)*(DWORD*)(a+8)=(DWORD)end;
    *(DWORD*)(ar+0xa0)=(DWORD)end;
    if(pos<0x80000000U&&end>=0x80000000ULL)large_log("LargeSave: duplication writer crossed 2 GiB successfully.\r\n");
}
static void large_read(BYTE *ar,BYTE *dst,int count) {
    BYTE *a=large_array(ar);DWORD pos=large_position(ar),num=*(DWORD*)(a+8);SIZE_T end;
    if(!count)return;
    end=(SIZE_T)pos+(DWORD)count;
    if(count<0||!dst||end>num||num>LARGE_LIMIT){large_stop(W("Large-save duplication reader encountered an invalid range. XCOM will close before reading outside the buffer. The save file has not been edited."));return;}
    ((void*(*)(void*,const void*,SIZE_T))(large_base+0x115e83a))(dst,*(BYTE**)a+(SIZE_T)pos,(DWORD)count);
    *(DWORD*)(ar+0xa0)=(DWORD)end;
    if(pos<0x80000000U&&end>=0x80000000ULL)large_log("LargeSave: duplication reader crossed 2 GiB successfully.\r\n");
    if(end==num&&num>=0x80000000U)large_log("LargeSave: duplication reader reached end of large buffer.\r\n");
}
static int large_at_end(BYTE *ar){return large_position(ar)>=*(DWORD*)(large_array(ar)+8);}
static void large_seek(BYTE *ar,DWORD pos){
    if((SIZE_T)pos>LARGE_LIMIT||pos>*(DWORD*)(large_array(ar)+8)){
        large_stop(W("Large-save duplication encountered an invalid seek. XCOM will close before accessing outside the buffer."));return;
    }
    *(DWORD*)(ar+0xa0)=pos;
}
static int large_check(BYTE *base){
    static const DWORD rva[2]={0x138b028,0x138b140};
    static const DWORD ser[2]={0xff7c0,0xff810};
    DWORD i;
    for(i=0;i<2;i++){
        SIZE_T *v=(SIZE_T*)(base+rva[i]);
        if(v[1]!=(SIZE_T)(base+ser[i])||v[10]!=(SIZE_T)(base+0x109a10)||v[11]!=(SIZE_T)(base+0x109f90)||v[12]!=(SIZE_T)(base+0xb6f30)||v[13]!=(SIZE_T)(base+0xff330))return 0;
    }
    return 1;
}
static int large_install(BYTE *base){
    DWORD old,tmp; SIZE_T *r=(SIZE_T*)(base+0x138b028),*w=(SIZE_T*)(base+0x138b140);
    /* Both tables share this page. All five original slots were checked first. */
    if(!CALL(VirtualProtect)(base+0x138b000,4096,4,&old))return 0;
    large_base=base;
    r[1]=(SIZE_T)large_read;w[1]=(SIZE_T)large_write;
    r[12]=w[12]=(SIZE_T)large_at_end;r[13]=w[13]=(SIZE_T)large_seek;
    if(!CALL(VirtualProtect)(base+0x138b000,4096,old,&tmp))return 0;
    return 1;
}
